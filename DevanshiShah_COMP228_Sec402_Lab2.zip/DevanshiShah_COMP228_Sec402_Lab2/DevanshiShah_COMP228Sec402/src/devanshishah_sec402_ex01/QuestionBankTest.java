package devanshishah_sec402_ex01;

public class QuestionBankTest {

	public static void main(String[] args) 
	{
		//creating an object of question bank.
			QuestionBank questionBank = new QuestionBank();
			questionBank.inputAnswer();
		


	}

}
